<?

use Bitrix\Main\ORM\Query\Result;
use Bitrix\Main\Text\Converter;
use Bitrix\Main\UserTable;
use Bitrix\Main\Context;
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true)
{
	die();
}

class CustomUsersList  extends CBitrixComponent
{

    protected $nav;

    public function onPrepareComponentParams($arParams)
    {
        $arParams['AJAX_ID'] = CAjax::GetComponentID($this->__name, $this->__template->__name, 'custom');
        $arParams["CACHE_TIME"] = $arParams["CACHE_TIME"] ?: 60*60;
        $arParams["PAGINATION_NAME"] = $arParams["PAGINATION_NAME"] ?: 'nav';
        $arParams["COUNT"] = $arParams["COUNT"] ?: '5';
        return $arParams;
    }

    public function getNav()
    {
        if (!$this->nav) {
            $nav = new \Bitrix\Main\UI\PageNavigation($this->arParams["PAGINATION_NAME"]);
            $nav->allowAllRecords(true)
            ->setPageSize($this->arParams["COUNT"])
            ->allowAllRecords(false)
            ->initFromUri();
            $this->nav = $nav;
        }
        
        return $this->nav;
    }

    public function getList(array $params): Result
    {
        $params['filter'] = array_merge(['ACTIVE'=>'Y'], (array)$params['filter']);
        return UserTable::getList($params);
    }

    public function getItems() {
        $nav = $this->getNav();
        $rs = $this->getList([
            "count_total" => true,
            "offset" => $nav->getOffset(),
            "limit" => $nav->getLimit(),
        ]);
        $return = [];
        while ($arUser = $rs->fetch()) {
            $return[] = $arUser;
        }
        $this->nav->setRecordCount($rs->getCount());
        return $return;
    }

    public function prepareLinks(&$data)
	{
		$addParam = \CAjax::GetSessionParam($this->arParams['AJAX_ID']);

		$regexpLinks = '/(<a\s[^>]*?>.*?<\/a>)/is'.BX_UTF_PCRE_MODIFIER;
		$regexpParams = '/([\w\-]+)\s*=\s*([\"\'])(.*?)\2/is'.BX_UTF_PCRE_MODIFIER;

		$arData = preg_split($regexpLinks, $data, -1, PREG_SPLIT_DELIM_CAPTURE);

        $dataCount = count($arData);
		if ($dataCount < 2)
        return;
        
		$ignoreAttributes = array(
            'onclick' => true,
			'target' => true
		);
		$search = array(
            $addParam.'&',
			$addParam,
			'AJAX_CALL=Y&',
			'AJAX_CALL=Y'
		);
		$dataChanged = false;
        
		for ($i = 1; $i < $dataCount; $i += 2)
		{
            if (!preg_match('/^<a\s([^>]*?)>(.*?)<\/a>$/is'.BX_UTF_PCRE_MODIFIER, $arData[$i], $match))
            continue;
            
			$params = $match[1];
            
			if (!preg_match_all($regexpParams, $params, $linkParams))
            continue;
            
			$strAdditional = ' ';
			$urlKey = -1;
			$ignoreLink = false;
            
			foreach ($linkParams[0] as $key => $value)
			{
                    if ($value == '')
                    continue;
                    
                    $paramName = strtolower($linkParams[1][$key]);
                    
                    if ($paramName === 'href')
                    {
                        $urlKey = $key;
                    }
                    elseif (isset($ignoreAttributes[$paramName]))
                    {
                        $ignoreLink = true;
                    break;
                }
                else
                {
                    $strAdditional .= $value.' ';
                }
            }
        
            if ($urlKey >= 0 && !$ignoreLink)
            {
                $url = Converter::getHtmlConverter()->decode($linkParams[3][$urlKey]);
                $url = str_replace($search, '', $url);
            
                $realUrl = $url;
                
                $pos = strpos($url, '#');
                if ($pos !== false)
                {
                    $realUrl = substr($realUrl, 0, $pos);
                }
                
                $realUrl .= strpos($url, '?') === false ? '?' : '&';
                $realUrl .= $addParam;
                
                $arData[$i] = \CAjax::GetLinkEx($realUrl, $url, $match[2], 'comp_'.$this->arParams['AJAX_ID'], $strAdditional);
                
                $dataChanged = true;
            }
        }
        
        if ($dataChanged)
        {
            $data = implode('', $arData);
        }
    }
    
    public function getPagination()
    {
        ob_start();
        $GLOBALS['APPLICATION']->IncludeComponent(
            "bitrix:main.pagenavigation",
            "",
            array(
                "NAV_OBJECT" => $this->getNav(),
            ),
            $this
        );
        $out = ob_get_contents();
        ob_end_clean();
        $this->prepareLinks($out);
        return $out;
    }

    public function downloadXML()
    {
        $xml = new DomDocument('1.0','utf-8');
        $users = $xml->appendChild($xml->createElement('users'));
        $rs = UserTable::getList([]);
        while ($arUser = $rs->fetch()) {
            $user = $users->appendChild($xml->createElement('user'));
            $login = $user->appendChild($xml->createElement('login'));
            $email = $user->appendChild($xml->createElement('email'));
            $login->appendChild($xml->createTextNode($arUser['LOGIN']));
            $email->appendChild($xml->createTextNode($arUser['EMAIL']));
        }
        $xml->formatOutput = true;
        
        $content = $xml->saveXML();
        $GLOBALS['APPLICATION']->RestartBuffer();
        header("Pragma: public");
        header("Content-Type: text/plain; charset=utf-8");
        header("Content-Disposition: attachment; charset=utf-8; filename=\"users.xml\"");
        header("Content-Transfer-Encoding: binary"); 
        header("Content-Length: " . strlen($content));
        echo $content;
        die;
    }

    public function downloadCSV()
    {
        $content = [];
        $content[] = 'LOGIN;EMAIL';
        $rs = UserTable::getList([]);
        while ($arUser = $rs->fetch()) {
            $content[] = $arUser['LOGIN'] . ';' . $arUser['EMAIL'];
        }
        $xml->formatOutput = true;
        
        $content = implode("\n", $content);
        $GLOBALS['APPLICATION']->RestartBuffer();
        header("Pragma: public");
        header("Content-Type: text/plain; charset=utf-8");
        header("Content-Disposition: attachment; charset=utf-8; filename=\"users.csv\"");
        header("Content-Transfer-Encoding: binary"); 
        header("Content-Length: " . strlen($content));
        echo $content;
        die;
    }

    public function executeComponent()
	{
        if (isset($_REQUEST['bxajaxid']) && ($_REQUEST['bxajaxid'] == $this->arParams['AJAX_ID'])) {
            if (isset($_REQUEST['downloadxml'])) {
                $this->downloadXML();
            }
            if (isset($_REQUEST['downloadcsv'])) {
                $this->downloadCSV();
            }
        }
        if (Context::getCurrent()->getRequest()->isAjaxRequest()) {
            $GLOBALS['APPLICATION']->RestartBuffer();
        }
        if ($this->StartResultCache($this->arParams['CACHE_TIME'], ($this->getNav())->getCurrentPage()))
        {
            $this->arResult['ITEMS'] = $this->getItems();
            $this->arResult['PAGINATION'] = $this->getPagination();
            $this->IncludeComponentTemplate();
        }
    }

}