<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true){die();}?>
<div id="comp_<?=$arParams['AJAX_ID']?>">
    <table>
        <tr>
            <td>
                <b>LOGIN</b>
            </td>
            <td>
                <b>EMAIL</b>
            </td>
        </tr>

        <? foreach ($arResult['ITEMS'] as $item): ?>
        <tr>
            <td>
                <?= $item['LOGIN'] ?>
            </td>
            <td>
                <?= $item['EMAIL'] ?>
            </td>
        </tr>
        <? endforeach; ?>
    </table>
    <?=$arResult['PAGINATION']; ?>
    <a href="<?=$APPLICATION->GetCurPageParam('bxajaxid=' . $arParams['AJAX_ID'] . '&downloadcsv')?>" target="_blank">Скачать в формате csv</a>
    <a href="<?=$APPLICATION->GetCurPageParam('bxajaxid=' . $arParams['AJAX_ID'] . '&downloadxml')?>" target="_blank">Скачать в формате xml</a>
</div>